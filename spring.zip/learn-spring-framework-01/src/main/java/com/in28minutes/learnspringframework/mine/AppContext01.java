package com.in28minutes.learnspringframework.mine;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppContext01 {

	public static void main(String[] args) {
		
		var context= new AnnotationConfigApplicationContext(AppConfiguration01.class);
		
		System.out.println(context.getBean("name"));
		System.out.println(context.getBean("age"));
		System.out.println("person1 "+context.getBean("person1"));
		System.out.println("person2 "+context.getBean("person2"));
		System.out.println("person3 "+context.getBean("person3"));

		
		//System.out.println(context.getBean(Person.class));
	}

}
