package com.in28minutes.learnspringframework;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.in28minutes.learnspringframework.game.GameRunner;
import com.in28minutes.learnspringframework.game.GamingConsole;

public class App03GamingSpringBeans {

	public static void main(String[] args) {

		try (var context= 
				new AnnotationConfigApplicationContext
					(GamingConfiguration.class)) 
			{
			
			context.getBean(GamingConsole.class).up();
			
			context.getBean(GameRunner.class).run();
			}
		
		// var game= new MarioGame();
		// var game= new SuperContraGame();
//		var game = new PacManGame(); // object creation
//
//		var gameRunner = new GameRunner(game); // game(dependency) is injected in GameRunner
		// Object Creation + Wiring of Dependencies
		// game is a dependency of GameRunner class
//		gameRunner.run();

	}

}
