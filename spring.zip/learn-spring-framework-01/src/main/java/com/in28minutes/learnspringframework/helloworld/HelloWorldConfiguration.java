package com.in28minutes.learnspringframework.helloworld;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

record Person(String name, int age, Address address) {

};

record Address(String firtstLine, String city) {

};

@Configuration
public class HelloWorldConfiguration {

	@Bean
	public String name() {
		return "Imraan Ali";
	}

	@Bean
	public int age() {
		return 24;
	}

	@Bean
	public Person person() {
		var person = new Person("person1 "+"Haajar Sufiya", 1, new Address("Mcy", "KMU"));
		person.age(); //getter method coming from Person class without declaring it in record
		return person;
	}

	@Bean
	public Person person2methodcall() {
		return new Person("person2 " + name(), age(), address());// using existing bean
	}

	@Bean
	public Person person3parameters(String name, int age, Address address2) {
		return new Person("person3 " + name, age, address2);// using existing bean in parameter
	}

	@Primary
	@Bean
	public Person person4parameters(String name, int age, Address address) {
		return new Person("person4 " + name, age, address);// using existing bean in parameter
	}
	
	@Bean
	public Person person5Qualifier(String name, int age, @Qualifier("address2qualifier") Address address) {
		return new Person("person5 " + name, age, address);// using existing bean in parameter
	}
	
	@Bean(name = "address1")
	@Primary
	public Address address() {
		return new Address("Address 1: "+"Melacauvery", "Kumbakonam");
	}

	@Bean(name = "address2")
	@Qualifier("address2qualifier")
	public Address address2() {
		return new Address("Address 2: "+"USA", "London");
	}
}