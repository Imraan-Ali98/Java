package com.in28minutes.learnspringframework.mine;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

record Person(String name, int age, Address address) {};

record Address(String firstLine, String city) {};

@Configuration
public class AppConfiguration01 {

	@Bean
	public String name() {
		return "Imraan Ali";
	}
	
	@Bean
	public int age() {
		return 24;
	}
	
	@Bean(name="person1")
	public Person person1() {
		return new Person("Haajar",1, new Address("Mcy", "Kmu"));
	}
	
	@Bean(name="person2")
	public Person person2() {
		return new Person(name(),age(), address());
	}
	
	@Bean(name="person3")
	public Person person3(String name, int age, Address address2) {
		return new Person(name,age,address2);
	}
	
	@Bean(name="address1")
	public Address address() {
		var address= new Address("Mcy","Kmu");
		return address;
	}
}
