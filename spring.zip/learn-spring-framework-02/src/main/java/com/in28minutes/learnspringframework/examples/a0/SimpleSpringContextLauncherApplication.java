package com.in28minutes.learnspringframework.examples.a0;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan //without parameter automatically scan the current package
public class SimpleSpringContextLauncherApplication {
//	@Bean
//	public GamingConsole game() {
//		var game = new PacManGame();
//		return game;
//	}

//	@Bean
//	public GameRunner gameRunner(GamingConsole game) {
//		System.out.println("Parameter: "+ game);
//		var gameRunner = new GameRunner(game);
//		return gameRunner;
//	}
	public static void main(String[] args) {

		try (var context = new AnnotationConfigApplicationContext(SimpleSpringContextLauncherApplication.class)) {

			Arrays.stream(context.getBeanDefinitionNames())
			.forEach(System.out::println);
		}

	}

}
